MyRummy

My game is based on the Indian variation of points rummy, a basic type rummy game where each player is given 10 or 13 cards and is supposed to make a run compulsorily followed by 2 melds.

As soon as the game window of my game appears the player is expected to pick the topmost card from either the stack of cards kept face down or the pack of cards kept face up, and is then also expected to pick return a card from her stack. The same steps are followed by the computer.

To pick a card--right click on reaching the position of the card
To return a card--left-click on reaching at the position

To calculate the score and thereby exit the game anytime, one has to press the SHIFT key, a new window appears and then the player is expected to sort her cards in the order of a run followed by the two melds.
The score is displayed after.

Score Calculation:
   The player who has the minimum score wins this game.
   Each player is awarded points on the bases of unclubbed cards in hand. The more the unclubbed cards, the higher the score. If a player is known not to possess a run, then even the melds are considered invalid.
